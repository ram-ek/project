<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width-device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">

        <!-- Font Awesome-->
        <script src="https://kit.fontawesome.com/47d83f34b3.js" crossorigin="anonymous"></script>

        <link href="https://fonts.googleapis.com/css?family=Candal|Lora&display=swap" rel="stylesheet">
        
        <script type='text/javascript' src='jquery-3.4.1.min.js'></script>
        <!--Custom Styling-->
        <link rel="stylesheet" href="css/style.css">


        <title>Diaster Mangement</title>
    </head>
    <body>
        <header>
            <div class="logo">
                <h1 class="logo-text"><span>Disaster Management</span></h1>
            </div>
            <!-- <i class="fa fa-bars menu-toggle" ></i> -->
            <ul class="nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="form.php">Request</a></li>
            </ul>
        </header>

        <!-- PAGE WRAPPER-->
        <div class="page-wrapper">

            <!--post slider-->
            <div class="post-slider">
                <h1 class="slider-title"> Requests</h1>
                <i class="fas fa-chevron-left prev"></i>
                <i class="fas fa-chevron-right next"></i>
                <div class="post-wrapper">

                <?php
    
                    include_once('connection.php');    
                    $query = "SELECT * from map";
                    $result = mysqli_query($con, $query);
                    ?>

                    <?php

                    while($rows=mysqli_fetch_assoc($result)) {

                    ?>                        
                        <div class="post"  
                             id="<?php echo htmlspecialchars($rows['map_id']); ?>" 
                             onclick="redirect(this.id)">

                            <img class="slider-image" src="uploads/<?php echo $rows['image']?>">
                             <h4><?php echo $rows['fname'], " ", $rows['lname']; ?></h4>
                             <p><?php echo $rows['request']?></p>
                        </div>
                    
                    <?php 
                      }
                    ?>
				</div>
         </div>
         
         <!--COntent-->
         <div class="content-clearfix">
             <div class="main-content">

                <b class="logo-text"><h2><br>Disaster Management</h2></b>
                <br>
                 <p  style="margin-top: 30px; border-radius: 10px; padding-bottom: 50px; font-family: 'Lora'; font-size: 18px; padding-bottom: 15vw;">
                        Disaster Management can be defined as the organization and management of resources and 
                        responsibilities for dealing with all humanitarian aspects of emergencies,
                         in particular preparedness, 
                         response and recovery in order to lessen the impact of disasters.
                         Disaster management in India refers to conservation of lives and property during a natural and man-made disaster. Disaster management plans are multi-layered and are planned to address issues such as floods, hurricanes, fires, mass failure of utilities and the rapid spread of disease. India is especially vulnerable to natural disasters because of its unique geo-climatic conditions, having recurrent floods, droughts, cyclones, earthquakes, and landslides. As India is a very large country, different regions are vulnerable to different natural disasters. For example, during rainy season the peninsular regions of South India is mostly affected by cyclones and states of West India experience severe drought during summer.When the capacity of a community or country to respond and recover from a disaster is overwhelmed, and upon request from the National Society, the International Federation uses its regional and international networks, assets and resources to bring assistance to the communities and National Red Cross Red Crescent Society which is assisting them. At an international level the International Federation advocates with Governments, international organisations and humanitarian donors for better practice and accountability in disaster management and greater respect of the dignity of the vulnerable people.

                 </p>

             </div>

             
         </div>
     </div>

     <!--Footer-->

     <div class="footer">
        <div class="footer-content">
            <div class="footer-section about-us">
                <h1 class="logo-text"><span>About Us</span></h1>
                <p style="padding-top: 5vw;">
                    Completely done by Rahul Yadav, Vivek Ram, Sachin Dubey.
                </p>
                <p>
                  As mini project for WDL.
                </p>
            </div>
            <div class="footer-section links">
                <h2>Quick Links</h2>
                <br>
                <ul>
                    <a href="#"><li>Events</li></a>
                    <a href="https://en.wikipedia.org/wiki/National_Disaster_Management_Authority_(India)"><li>Team</li></a>
                    <a href="https://ndma.gov.in/en/"><li>Information</li></a>
                    <!-- <a href="#"><li>Mentors</li></a> -->
            </div>
            <div class="footer-section contact-form">
                <h2>Contact Us</h2>
                <br>
                <form action="index.html" method="post">
                    <input type="email" name="email" class="text-input contact-input" placeholder="Your email address....">
                    <textarea name="message" class="text-input contact-input" placeholder="Your mesaage...."></textarea>


            </div>
            
        </div>
        <div class="footer-bottom">
            &copy; |Designed By Rahul Yadav Vivek Ram Sachin Dubey
        </div>
     </div>
       <!-- J-Query--> 
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" ></script> 
       
       <!-- Slick -->
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
 				
       
        <script src="js/script.js"></script>
        
<script>
  
  function redirect(ID){    
      var a = ID;
      $.post('temp.php',{id:a},
        function(data){
            window.location.href = "request.php";
        });
  }

</script>

				


    </body>
</html>