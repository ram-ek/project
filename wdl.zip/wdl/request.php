<!DOCTYPE html>
 <html>
 <head>
 	<title>Request</title>
 	<script type='text/javascript' src='jquery-3.4.1.min.js'></script>
  <link href="https://fonts.googleapis.com/css?family=Candal|Lora&display=swap" rel="stylesheet">
 	<meta name="viewport" content="initial-scale=1.0">
    <meta charset="utf-8">
	<link rel="stylesheet" href="css/style.css">

 </head>
 <body>

 <header>
            <div class="logo">
                <h1 class="logo-text"><span>Disaster Management</span></h1>
            </div>
            <!-- <i class="fa fa-bars menu-toggle" ></i> -->
            <ul class="nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="form.php">Request</a></li>
            </ul>
        </header>

 	 <?php 
      //Variavles to use in html
 	    session_start(); 	
 		$fname = $_SESSION['fname'];
  		$lname = $_SESSION['lname'];
  		$gender = $_SESSION['gender'];
  		$request = $_SESSION['request'];
  		$lat = $_SESSION['lat'];
  		$lng = $_SESSION['lng'];  	
	?>

  <!-------------MAP------------>
  	<!-- <div class="form-request"> -->
  <div class="reqHolder">
    <div class="details">    
       <h3 class="temp">Name: </h3><h3 class="det"> <?php echo $fname, " ", $lname ?></h3>
        <br><br>
        <h3 class="temp">gender: </h3><h3 class="det"> <?php echo $gender ?></h3>
        <br>
        <br>
        <h3 class="temp">Request: </h3>
        <br><br><br>
        
        <h3 class="det"><?php echo $request ?></h3>
        <!-- <h2><label>Latitude: <?php echo $lat ?></label></h2>
        <br>
        <br>
        <h2><label>Longitutude:<?php echo $lng ?></label></h2>
        <br> -->
        <br><br><br><br>
    </div>  
    <div class="details1">
      <div id="map"></div>
  	</div>
  </div>
  <script>
    var map;
    function initMap() {
      map = new google.maps.Map(document.getElementById('map'), {
        center: {lat: <?php echo $lat ?>, lng: <?php echo $lng?>},
        zoom: 17
      });
      var marker = new google.maps.Marker({
      	position: {lat: <?php echo $lat ?>, lng: <?php echo $lng?>}, 
      	map: map
      });

    }
  </script>

  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB3UjNHkxFsJ-lmCOIDINFpHkXfthClJkA&callback=initMap"
  async defer></script>
	<!-- </div> -->
 </body>
 </html>